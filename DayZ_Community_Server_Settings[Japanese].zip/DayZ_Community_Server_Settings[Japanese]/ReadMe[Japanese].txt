本稿は公開サーバーの構築、設定に関する記事を掲載します。
少々複雑な項目がありますが、プライベートサーバーが構築できたのなら大丈夫です。
*本稿ではBecフォルダ、DZSALModServer.exe、SteamCMDフォルダをDayZ Serverフォルダ直下に配置した内容で解説します。
*!Workshopは隠しフォルダとなっているため、フォルダオプションで表示するように設定してください。
*フォルダオプションで全ての拡張子が表示されるように設定してください。

1.①SteamCMD、②Bec、③DZSALModServerの導入

2.battleyeの設定

3.Becの設定

4.導入するModについて

5.Modlistについて

6.ポートの開放

7.サーバー起動用のバッチファイルの作成

8.serverDZ.cfgの設定



1.①SteamCMD、②Bec、③DZSALModServerの導入
①SteamCMDの導入
下記リンクからSteamCMD.exeをダウンロードしてください。
https://developer.valvesoftware.com/wiki/SteamCMD
DayZServerフォルダ直下にSteamCMDフォルダを作成してください。
配置後SteamCMD.exeを起動するとファイルが展開されます。
展開後、>quitで終了します。
下記例のようにSteamCMDフォルダ以下に階層フォルダを作成してください。
例:C:\Steam\steamapps\common\DayZServer\SteamCMD\steamapps\workshop\content\221100

②Becの導入
下記リンクからBattlEye-Extended-Controls-master.zipをダウンロードしてください。
https://github.com/worldwidesorrow/BattlEye-Extended-Controls
解凍後、BattlEye-Extended-Controls-master\server_tools\Becと展開し、Becフォルダをコピーしてください。
コピーしたBecフォルダをDayZServerフォルダ直下にペーストしてください。

③DZSALModServerの導入
下記リンクのDownloadからdzsalmodserver.zipをダウンロードしてください。
http://dayzsalauncher.com/#/tools
dzsalmodserver.zipを展開して、DZSALModServer.exeをDayZ Serverフォルダ直下に配置してください。
*NET Framework 4.7以上のバージョンが必要となります。



2.battleyeの設定
DayZServerフォルダ直下にあるbattleyeフォルダを展開してください。
①テキストエディタでbans.txtを作成してください。(中は空白で構いません。)

②テキストエディタでbeserver.cfg、BEServer_x64.cfgを作成してください。2つともに以下の4行をコピー&ペーストしてください。

RConPassword 1234
RestrictRCon 0
RConPort 2302
RConIP 127.0.0.1

*RConPasswordは自分でわかるものを設定してください。
*RConPortとRConIPを自分のサーバーのものへ編集してください。



3.Becの設定
DayZServerフォルダ直下にあるBecフォルダを展開してください。
Configフォルダを展開しConfig.cfgをテキストエディタで展開してください。下記のIP、Port、BepPathを編集してください。

Ip = 127.0.0.1
自分のサーバーのものへ編集してください。

Port = 2302
自分のサーバーのものへ編集してください。

BePath = C:\steam\steamapps\common\DayZServer\battleye
battleyeフォルダが配置されている階層を指定します。



4.導入するModについて
①modをサブスクライブ
サーバーに入れたいmodをSteam Workshopでサブスクライブしてください。

②DayZLauncherを起動
modのダウンロードが完了したらDayZLauncherを起動してください。
これによりダウンロードしたファイルがsteamapps\common\DayZ\!Workshopフォルダ内に表示されます。
*!Workshopは隠しフォルダとなっているため、フォルダオプションで表示するように設定してください。

③modをサーバーフォルダ直下へコピー
名前が@から始まるフォルダがmod本体となります。
これをDayZServerフォルダ直下にコピー&ペーストしてください。
DayZServer_x64.exeやserverDZ.cfgがある場所です。

④bikeyファイルをコピー
modの中のkeysフォルダ内にある○○○.bikeyを、DayZServer\keysフォルダへコピー&ペーストしてください。



5.Modlistについて
DayZServerフォルダ直下にテキストエディタ等でModlist.txtを作成してください。
作成したModlist.txtをテキストエディタ等で編集してください。
MODID,@ModNameを入力します。

MODIDは
①Steam Workshopの導入したいMODページのURL末尾に記されているid=10ケタの番号がMODIDとなります。
②または、!Workshop内にサブスクライブしたMODフォルダを展開し、meta.cppをテキストエディタ等で展開。publishedid = 10ケタの番号;がMODIDとなります。

Modlist.txtの記入例
1122334455,@ModName1
6677889900,@ModName2

失敗例
1122334455,@Mod Name 1
6677889900,@Mod!Name2

*上記失敗例のように@ModNameはスペースや一部記号によっては読み込めません。
*DayZServerフォルダ直下に配置した@ModName及びModlist.txtの@ModNameのスペースを削除したり、一部記号を修正してください。
*例:1605653648,@FIDOvPACK4のように修正が必要です。



6.ポートの開放
サーバーのポート及び、アップロードサーバーのポート、steamのポート、それぞれのポート開放が必要になります。
ポートの開放手順に関しては個人間の環境によって異なることから割愛します。

例
DayZServer=UDP:2302
DZSALModServer=TCP:2312(DayZServerポート+10の値のTCPポートの開放が必要です。)
Steam=UDP:27016



7.サーバー起動用のバッチファイルの作成
DayZ Serverフォルダ直下に、拡張子がbatのファイルを作成してください。
DayZServer_x64.exeがある場所です。
名前はなんでもOK。
例:server start.bat
作成したものをテキストエディタで開き、以下をそのままコピー&ペーストしてください。

--------------------------------------------------ここから↓-------------------------------------------------
	
    @echo off
    COLOR 0A
    :start
    ::Server name
    set serverName=ServerName
    ::Server files location
    set serverLocation="C:\steam\steamapps\common\DayZServer"
    ::Server Profile Folder Location
    set serverProfiles=C:\steam\steamapps\common\DayZServer\profiles
    ::Server Port
    set serverPort=2302
    ::Logical CPU cores to use (Equal or less than available)
    set serverCPU=4
    ::Server config
    set serverConfig=serverDZ.cfg
    ::InstanceID Number
    set instanceIdNumber=1
    ::exe
    set dayzsaExe=DayZServer_x64.exe
    set dzsalExe=DZSALModServer.exe
    set becExe=Bec.exe
    ::Battleye Parameters::
    set beFolder=C:\steam\steamapps\common\DayZServer\battleye
    set becFolder=C:\steam\steamapps\common\DayZServer\Bec
    set becConfig=Config.cfg
    ::Mod Settings::
    set serverMod=
    set modList=(C:\Steam\steamapps\common\DayZServer\Modlist.txt)
    set steamWorkshop=C:\Steam\steamapps\common\DayZServer\SteamCMD\steamapps\workshop\content\221100
    set steamcmdLocation=C:\Steam\steamapps\common\DayZServer\SteamCMD
    set steamUser=SteamID
    set steamcmdDel=5
    setlocal EnableDelayedExpansion 

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

    echo Agusanz

    ::Sets title for terminal (DONT edit)
    title %serverName% batch
    ::DayZServer location (DONT edit)
    cd "%serverLocation%"
    echo (%time%) %serverName% started.

    goto checkServer
    pause

    :checkServer
    tasklist /fi "imagename eq %dayzsaExe%" 2>NUL | find /i /n "%dayzsaExe%">NUL
    if "%ERRORLEVEL%"=="0" goto checkBEC
    cls
    echo Server is not running, taking care of it..
    goto killserver

    :checkBEC
    tasklist /fi "imagename eq %becExe%" 2>NUL | find /i /n "%becExe%">NUL
    if "%ERRORLEVEL%"=="0" goto loopServer
    cls
    echo Bec is not running, taking care of it..
    goto startBEC

    :loopServer
    FOR /L %%s IN (30,-1,0) DO (
    cls
    echo Server is running. Checking again in %%s seconds.. 
    timeout 1 >nul
    )
    goto checkServer

    :killserver
    taskkill /f /im %becExe%
    taskkill /f /im %dayzsaExe%
    taskkill /f /im %dzsalExe%
    goto checkmods

    :checkmods
    cls
    FOR /L %%s IN (%steamcmdDel%,-1,0) DO (
    cls
    echo Checking for mod updates in %%s seconds.. 
    timeout 1 >nul
    )
    echo Reading in configurations/variables set in this batch and modList. Updating Steam Workbench mods...
    @ timeout 1 >nul
    cd %steamcmdLocation%
    for /f "tokens=1,2 delims=," %%g in %modList% do steamcmd.exe +login %steamUser% +workshop_download_item 221100 "%%g" +quit
    cls
    echo Steam Workshop files up to date! Syncing Workbench source with server destination...
    @ timeout 2 >nul
    cls
    @ for /f "tokens=1,2 delims=," %%g in %modList% do robocopy "%steamWorkshop%\%%g" "%serverLocation%\%%h" *.* /mir
    @ for /f "tokens=1,2 delims=," %%g in %modList% do forfiles /p "%serverLocation%\%%h" /m *.bikey /s /c "cmd /c copy @path %serverLocation%\keys"
    cls
    echo Sync complete! If sync not completed correctly, verify configuration file.
    @ timeout 3 >nul
    cls
    set "MODS_TO_LOAD="
    for /f "tokens=1,2 delims=," %%g in %modList% do (
    set "MODS_TO_LOAD=!MODS_TO_LOAD!%%h;"
    )
    set "MODS_TO_LOAD=!MODS_TO_LOAD:~0,-1!"
    ECHO Will start DayZ with the following mods: !MODS_TO_LOAD!%
    @ timeout 3 >nul
    goto startserver

    :startserver
    cls
    echo Starting DayZ SA Server.
    timeout 1 >nul
    cls
    echo Starting DayZ SA Server..
    timeout 1 >nul
    cls
    echo Starting DayZ SA Server...
    cd "%serverLocation%"
    start %dzsalExe% -config=%serverConfig% -instanceId=%instanceIdNumber% -cpuCount=%serverCPU% -port=%serverPort% -dologs -adminlog -netlog -freezecheck -BEpath=%beFolder% -profiles=%serverProfiles% "-servermod=%serverMod%" "-mod=!MODS_TO_LOAD!%" "-scrAllowFileWrite"
    FOR /L %%s IN (30,-1,0) DO (
    cls
    echo Initializing server, wait %%s seconds to initialize Bec.. 
    timeout 1 >nul
    )
    goto startbec

    :startbec
    cls
    echo Starting BEC.
    timeout 1 >nul
    cls
    echo Starting BEC..
    timeout 1 >nul
    cls
    echo Starting BEC...
    timeout 1 >nul
    cd "%becFolder%"
    start %becExe% -f %becConfig% --dsc
    goto checkServer

--------------------------------------------------ここまで↑-------------------------------------------------

各編集個所の解説
set serverName=
名前は何でもOK。

set serverLocation=
DayZServerファイルが配置されている階層を指定します。
例:set serverLocation="C:\steam\steamapps\common\DayZServer"

set serverProfiles=
サーバーログを保存する階層を指定します。トレーダーmodやcommunity-online-toolsのようなゲーム内管理者ツールを使うなら必須。
例:set serverProfiles=C:\steam\steamapps\common\DayZServer\profiles
この場合、もちろんサーバーフォルダ直下にprofilesという名前のフォルダを作らないといけません。

set serverPort=
DayZServer用のポートを入力してください。
例:2302

set serverCPU=
サーバー機で使用するCPUコア数を指定してください。

set serverConfig=
デフォルトはserverDZ.cfgになります。

set instanceIdNumber=
デフォルトは1になります。

set dayzsaExe=
デフォルトはDayZServer_x64.exeになります。

set dzsalExe=
デフォルトはDZSALModServer.exeになります。

set becExe=
デフォルトはBec.exeになります。

set beFolder=
battleyeフォルダが配置されている階層を指定します。
例:set beFolder=C:\steam\steamapps\common\DayZServer\battleye

set becFolder=
Becフォルダを配置した階層を指定します。
例:set becFolder=C:\steam\steamapps\common\DayZServer\Bec

set becConfig=
デフォルトはConfig.cfgになります。

set serverMod=
サーバーMODを導入する際に記入します。
Survivor Missions　ModのようなサーバーMODを導入する際に記入します。
例:set serverMod=@ModName1;@ModName2

set modList=
4.Modlistについての手順で作成したModlist.txtファイルを配置した階層を指定します。
例:set modList=(C:\Steam\steamapps\common\DayZServer\Modlist.txt)

set steamWorkshop=
2.Modのアップロードについての手順で作成した221100までの階層を指定します。
例:set steamWorkshop=C:\Steam\steamapps\common\DayZServer\SteamCMD\steamapps\workshop\content\221100

set steamcmdLocation=
SteamCMDフォルダを配置した階層を指定します。
例:set steamcmdLocation=C:\Steam\steamapps\common\DayZServer\SteamCMD

set steamUser=
SteamのログインIDを入力してください。(無料アカウントの使用を推奨。DayZの購入は必要ありません。)

set steamcmdDel=
SteamCMDの待機時間。変更する必要はありません。



8.serverDZ.cfgの設定
①基本設定

hostname =
サーバーネーム。

password =
参加時のパスワード。
設定しないのなら空白のまま。

passwordAdmin =
管理者用パスワード。

enableWhitelist =
ホワイトリストの使用可否。
デフォルトは0(否)

maxPlayers =
サーバーへの参加人数。

verifySignatures =
.bisignファイルに対して.pbosを検証します。
デフォルトは2(MODのバージョン不一致だと参加できない。)

forceSameBuild =
サーバーは、サーバーと同じ.exeリビジョン（値0-1）を持つクライアントへの接続のみを許可します。
デフォルトは1

disableVoN =
ボイス機能のオン/オフ。
デフォルトは0(オン)

vonCodecQuality =
ボイス機能の音質設定。
0~30まで設定可能。

disable3rdPerson=
3人称にしない設定のオン/オフ
デフォルトは0(オフ:3人称にする)

disableCrosshair=
クロスヘアを使用しない設定のオン/オフ
デフォルトは0(オフ:クロスヘアを表示する)

serverTime=
サーバーの最初のゲーム内時間。"SystemTime"は、マシンのローカル時間を意味します。
または詳細に設定する場合は"yyyy/mm/dd/hh/mm"と設定します。
例:"SystemTime"または、日付を詳細に設定する場合は"2020/04/01/07/00"(2020年4月1日AM7時00分)

serverTimeAcceleration=
加速時間。
乗数である数値（0.1-64）。したがって、24に設定されている場合、時間は通常よりも24倍速く移動します。丸一日が1時間で過ぎま​​す。

serverNightTimeAcceleration=
夜間の加速時間。
数値は乗数（0.1〜64）であり、serverTimeAcceleration値も乗算されます。
したがって、serverTimeAccelerationが4に設定され、serverTimeAccelerationが2に設定されている場合、夜間の時間加速は通常より8倍速くなります。

serverTimePersistent=
サーバー起動時の開始時間についてオン/オフ
デフォルトは0(serverTime=で設定された時間から始まります。)
1の場合は前回起動時から時間が続きます。

guaranteedUpdates =
ゲームサーバーで使用される通信プロトコル（番号1のみを使用）

loginQueueConcurrentPlayers  =
同時にログインできる人数の上限。設定以上の人数が同時に接続しようとすると待機に回されるようになります。

loginQueueMaxPlayers =
待機人数の上限。

instanceId = 
DayZサーバーインスタンスID。ボックスごとのインスタンスの数と、永続化ファイルを含むそのストレージフォルダーを識別します。
デフォルトは1。

storageAutoFix =
永続性ファイルが破損しているかどうかを確認し、破損しているファイルを空のファイル（値0-1）に置き換えます

template =
起動時に開始されるワールド設定。
デフォルトは"dayzOffline.chernarusplus"
DLCのLivoniaを選択する場合は"dayzOffline.enoch"に変更することで選択可能。

②追加設定(必要に応じて追記して設定可能となります。)*編集者も未検証な項目がありますので、一部翻訳のみの項目があります。
respawnTime =
プレイヤーのリスポーン時間。
5だと復活が5秒になります。

motd[] =
ゲーム内チャットに表示されるその日の2行のメッセージ
例:motd[]= {"Welcome to my server.", "Hosted in the net."};

motdInterval =
各メッセージ間の時間間隔（秒単位）

maxPing=
サーバーがユーザーをキックするまでの最大ping値（ミリ秒単位の値）

timeStampFormat =
.rptファイルのタイムスタンプの形式（値Full / Short）
例:timeStampFormat = "Short";

logAverageFps =
平均サーバーFPS（秒単位の値）をログに記録します。"-doLogs"起動パラメーターを有効にする必要があります。

logMemory  =
サーバーのメモリ使用量（秒単位の値）をログに記録し、"-doLogs"起動パラメーターを有効にする必要があります。

logPlayers  =
現在接続されているプレーヤーの数（秒単位の値）をログに記録し、"-doLogs"起動パラメーターをアクティブにする必要があります。

logFile  =
サーバーコンソールログを他のサーバーログと同じフォルダ内のファイルに保存します。ログファイル(.log)を作成する必要があります。
例:logFile  =  "server_console.log"

adminLogPlayerHitsOnly  =
1-プレーヤーのヒットのみを記録/ 0-すべてのヒットを記録。（動物/ゾンビ）

adminLogPlacement  =
1-ログ配置アクション（トラップ、テント）/0-オフ

adminLogBuildActions  =
1-ベースビルドアクションのログ（ビルド、解体、破棄）/0-オフ

adminLogPlayerList =
1-5分ごとの位置で定期的なプレーヤーリストを記録/0-オフ

enableDebugMonitor  =
画面の隅にあるデバッグウィンドウを使用して、キャラクターに関する情報を表示します（値0-1）


steamQueryPort  =
steam用のport。
例:27016

allowFilePatching  =
1に設定すると、「-filePatching」起動パラメーターが有効になっているクライアントの接続が有効になります。

SimulatedPlayersBatch  =
フレームごとにシミュレーションできるプレーヤー数の制限を設定します（サーバーのパフォーマンス向上のため）。20と設定した場合20フレームを下回ったら制限がかかります。

multithreadedReplication  =
サーバーのレプリケーションシステムのマルチスレッド処理を有効にします。
ワーカースレッドの数は、 "maxcores"および "reservedcores"パラメーター（値0-1）によってdayzSettings.xmlのジョブシステムの設定によって導出されます。

networkRangeClose  =
アイテムを含む近いオブジェクト（fiバックパック）のスポーンのネットワークバブル距離。メートル単位で設定され、設定されていない場合のデフォルト値は20です。

networkRangeNear  =
ニアインベントリアイテムオブジェクトのスポーン（デスポーン+ 10％）のネットワークバブル距離、メートル単位で設定、設定されていない場合のデフォルト値は150です。

networkRangeFar  =
遠方のオブジェクト（在庫アイテム以外）のスポーン（despawn + 10％）のネットワークバブル距離。メートル単位で設定され、設定されていない場合のデフォルト値は1000です。

networkRangeDistantEffect  =
エフェクトのスポーンのネットワークバブル距離（現在はサウンドエフェクトのみ）、メートル単位で設定、設定されていない場合のデフォルト値は4000です。

defaultVisibility =
サーバー上での最も高いテレインレンダリング距離（DayZクライアントプロファイルの "viewDistance ="より高い場合、clientsideパラメータが適用されます）。

defaultObjectViewDistance =
サーバー上で最も高いオブジェクトレンダリング距離（DayZクライアントプロファイルの "preferredObjectViewDistance ="より高い場合、クライアント側パラメーターが適用されます）。

lightingConfig =
ゲーム内の明るさの設定。
0:夜間は真っ暗
1:夜間は星明りが見える
2:夜間は星明りが見え、陽光がより現実的になります。

disablePersonalLight  =
サーバーに接続されているすべてのクライアントの個人用ライトを無効にします。

disableBaseDamage  =
フェンスと監視塔の損傷/破壊を無効にするには1に設定します。

disableContainerDamage  =
1に設定すると、テント、バレル、木箱等の設置物の損傷/破壊が無効になります。